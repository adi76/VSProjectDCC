﻿Imports System.DirectoryServices

Public Class LoginForm3

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Public Function ValidateActiveDirectoryLogin(ByVal Domain As String, ByVal Username As String, ByVal Password As String) As Boolean

        Try
            'Build LDAP Correct Search String
            Dim SearchString As String = Nothing

            For i = 0 To Domain.Split(".").Count - 1
                SearchString &= "DC=" & Domain.Split(".")(i) & ", "
            Next

            SearchString = SearchString.TrimEnd(", ")
            'Setup Connection to LDAP
            Dim DirEntry As New DirectoryEntry("LDAP:  //" & SearchString)

            DirEntry.Username = Username
            DirEntry.Password = Password
            DirEntry.AuthenticationType = AuthenticationTypes.Secure

            'Test the Uesrname and Password by try a Native Ojbect Binding
            Dim NOjb As [Object] = DirEntry.NativeObject

            'If Try statement get this far the username and password have passed the check
            Return True

        Catch ex As Exception
            'Username/Password/Domain are combination are wrong
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        If (ValidateActiveDirectoryLogin("net.pp", UsernameTextBox.Text, PasswordTextBox.Text)) Then
            Form1.Show()
        End If
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginForm3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
