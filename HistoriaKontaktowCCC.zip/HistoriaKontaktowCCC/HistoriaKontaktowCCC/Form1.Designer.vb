﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CCDBPPWielunDataSet As HistoriaKontaktowCCC.CCDBPPWielunDataSet
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Nagranie = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Zapis = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.CALLSBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MSSQL = New System.Windows.Forms.BindingSource(Me.components)
        Me.CLIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CL_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CL_DATA_FROM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CL_DATA_PICKUP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CL_DATA_TO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CzasPolaczenia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ByAgent = New System.Windows.Forms.CheckBox()
        Me.ListaAgentow = New System.Windows.Forms.ComboBox()
        Me.WithRecording = New System.Windows.Forms.CheckBox()
        Me.dtp_data_do = New System.Windows.Forms.DateTimePicker()
        Me.cb_data = New System.Windows.Forms.CheckBox()
        Me.dtp_data = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.combo_rodzaj = New System.Windows.Forms.ComboBox()
        Me.btn_nowe = New System.Windows.Forms.Button()
        Me.numertelefonu = New System.Windows.Forms.TextBox()
        Me.btn_koniec = New System.Windows.Forms.Button()
        Me.btn_export = New System.Windows.Forms.Button()
        Me.btn_search = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PrefixList = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CLIDDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.IDPołączeniaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumerTelefonuDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RodzajPołączeniaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.opis_ilosc_pozycji = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ilosc_pozycji_znalezionych = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbl_error_data_prefix = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lbl_error_data = New System.Windows.Forms.ToolStripStatusLabel()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SearchBy = New System.Windows.Forms.ComboBox()
        CCDBPPWielunDataSet = New HistoriaKontaktowCCC.CCDBPPWielunDataSet()
        CType(CCDBPPWielunDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CALLSBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MSSQL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CCDBPPWielunDataSet
        '
        CCDBPPWielunDataSet.DataSetName = "CCDBPPWielunDataSet"
        CCDBPPWielunDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.DataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Nagranie, Me.Zapis})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.Location = New System.Drawing.Point(2, 3)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView1.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.ShowCellToolTips = False
        Me.DataGridView1.ShowEditingIcon = False
        Me.DataGridView1.Size = New System.Drawing.Size(780, 343)
        Me.DataGridView1.TabIndex = 0
        Me.DataGridView1.VirtualMode = True
        '
        'Nagranie
        '
        Me.Nagranie.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Nagranie.DataPropertyName = "Nagranie"
        Me.Nagranie.HeaderText = ""
        Me.Nagranie.Name = "Nagranie"
        Me.Nagranie.ReadOnly = True
        Me.Nagranie.Width = 30
        '
        'Zapis
        '
        Me.Zapis.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.Zapis.DataPropertyName = "Zapis"
        Me.Zapis.HeaderText = ""
        Me.Zapis.Name = "Zapis"
        Me.Zapis.ReadOnly = True
        Me.Zapis.Width = 30
        '
        'CALLSBindingSource
        '
        Me.CALLSBindingSource.DataMember = "CALLS"
        Me.CALLSBindingSource.DataSource = Me.MSSQL
        '
        'MSSQL
        '
        Me.MSSQL.DataSource = CCDBPPWielunDataSet
        Me.MSSQL.Position = 0
        '
        'CLIDDataGridViewTextBoxColumn
        '
        Me.CLIDDataGridViewTextBoxColumn.DataPropertyName = "CL_ID"
        Me.CLIDDataGridViewTextBoxColumn.HeaderText = "ID połączenia"
        Me.CLIDDataGridViewTextBoxColumn.Name = "CLIDDataGridViewTextBoxColumn"
        Me.CLIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CL_ID
        '
        Me.CL_ID.DataPropertyName = "CL_ID"
        Me.CL_ID.HeaderText = "CL_ID"
        Me.CL_ID.Name = "CL_ID"
        '
        'CL_DATA_FROM
        '
        Me.CL_DATA_FROM.DataPropertyName = "CL_DATA_FROM"
        Me.CL_DATA_FROM.HeaderText = "CL_DATA_FROM"
        Me.CL_DATA_FROM.Name = "CL_DATA_FROM"
        '
        'CL_DATA_PICKUP
        '
        Me.CL_DATA_PICKUP.DataPropertyName = "CL_DATA_PICKUP"
        Me.CL_DATA_PICKUP.HeaderText = "CL_DATA_PICKUP"
        Me.CL_DATA_PICKUP.Name = "CL_DATA_PICKUP"
        '
        'CL_DATA_TO
        '
        Me.CL_DATA_TO.DataPropertyName = "CL_DATA_TO"
        Me.CL_DATA_TO.HeaderText = "CL_DATA_TO"
        Me.CL_DATA_TO.Name = "CL_DATA_TO"
        '
        'CzasPolaczenia
        '
        Me.CzasPolaczenia.DataPropertyName = "CzasPolaczenia"
        Me.CzasPolaczenia.HeaderText = "CzasPolaczenia"
        Me.CzasPolaczenia.Name = "CzasPolaczenia"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.SearchBy)
        Me.Panel1.Controls.Add(Me.ByAgent)
        Me.Panel1.Controls.Add(Me.ListaAgentow)
        Me.Panel1.Controls.Add(Me.WithRecording)
        Me.Panel1.Controls.Add(Me.dtp_data_do)
        Me.Panel1.Controls.Add(Me.cb_data)
        Me.Panel1.Controls.Add(Me.dtp_data)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.combo_rodzaj)
        Me.Panel1.Controls.Add(Me.btn_nowe)
        Me.Panel1.Controls.Add(Me.numertelefonu)
        Me.Panel1.Controls.Add(Me.btn_koniec)
        Me.Panel1.Controls.Add(Me.btn_export)
        Me.Panel1.Controls.Add(Me.btn_search)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(784, 63)
        Me.Panel1.TabIndex = 3
        '
        'ByAgent
        '
        Me.ByAgent.AutoSize = True
        Me.ByAgent.Location = New System.Drawing.Point(359, 37)
        Me.ByAgent.Name = "ByAgent"
        Me.ByAgent.Size = New System.Drawing.Size(54, 17)
        Me.ByAgent.TabIndex = 16
        Me.ByAgent.Text = "Agent"
        Me.ToolTip1.SetToolTip(Me.ByAgent, "Zawęź wyniki wyszukiwania do konkretnego agenta")
        Me.ByAgent.UseVisualStyleBackColor = True
        '
        'ListaAgentow
        '
        Me.ListaAgentow.Enabled = False
        Me.ListaAgentow.FormattingEnabled = True
        Me.ListaAgentow.Location = New System.Drawing.Point(415, 34)
        Me.ListaAgentow.Name = "ListaAgentow"
        Me.ListaAgentow.Size = New System.Drawing.Size(162, 21)
        Me.ListaAgentow.TabIndex = 6
        '
        'WithRecording
        '
        Me.WithRecording.AutoSize = True
        Me.WithRecording.Location = New System.Drawing.Point(270, 37)
        Me.WithRecording.Name = "WithRecording"
        Me.WithRecording.Size = New System.Drawing.Size(87, 17)
        Me.WithRecording.TabIndex = 5
        Me.WithRecording.Text = "Z nagraniami"
        Me.ToolTip1.SetToolTip(Me.WithRecording, "Pokaż tylko kontakty, które zakończyły się rozmową z konsultantem")
        Me.WithRecording.UseVisualStyleBackColor = True
        '
        'dtp_data_do
        '
        Me.dtp_data_do.CustomFormat = ""
        Me.dtp_data_do.Enabled = False
        Me.dtp_data_do.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.dtp_data_do.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_data_do.Location = New System.Drawing.Point(469, 8)
        Me.dtp_data_do.Name = "dtp_data_do"
        Me.dtp_data_do.Size = New System.Drawing.Size(108, 23)
        Me.dtp_data_do.TabIndex = 4
        Me.ToolTip1.SetToolTip(Me.dtp_data_do, "Data do")
        '
        'cb_data
        '
        Me.cb_data.AutoSize = True
        Me.cb_data.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.cb_data.Location = New System.Drawing.Point(270, 10)
        Me.cb_data.Name = "cb_data"
        Me.cb_data.Size = New System.Drawing.Size(84, 17)
        Me.cb_data.TabIndex = 2
        Me.cb_data.Text = "Data między"
        Me.cb_data.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ToolTip1.SetToolTip(Me.cb_data, "Zawęź wyniki wyszukiwania do dat")
        Me.cb_data.UseVisualStyleBackColor = True
        '
        'dtp_data
        '
        Me.dtp_data.CustomFormat = ""
        Me.dtp_data.Enabled = False
        Me.dtp_data.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.dtp_data.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtp_data.Location = New System.Drawing.Point(361, 8)
        Me.dtp_data.Name = "dtp_data"
        Me.dtp_data.Size = New System.Drawing.Size(106, 23)
        Me.dtp_data.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dtp_data, "Data od")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label3.Location = New System.Drawing.Point(49, 37)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 15)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Typ połączeń"
        '
        'combo_rodzaj
        '
        Me.combo_rodzaj.BackColor = System.Drawing.SystemColors.Window
        Me.combo_rodzaj.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.combo_rodzaj.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.combo_rodzaj.FormattingEnabled = True
        Me.combo_rodzaj.Location = New System.Drawing.Point(134, 33)
        Me.combo_rodzaj.Name = "combo_rodzaj"
        Me.combo_rodzaj.Size = New System.Drawing.Size(126, 24)
        Me.combo_rodzaj.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.combo_rodzaj, "Wybierz typ połączeń:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " - przychodzące" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " - wychodzące")
        '
        'btn_nowe
        '
        Me.btn_nowe.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_nowe.Image = Global.HistoriaKontaktowCCC.My.Resources.Resources.big_new_search
        Me.btn_nowe.Location = New System.Drawing.Point(632, 7)
        Me.btn_nowe.Name = "btn_nowe"
        Me.btn_nowe.Size = New System.Drawing.Size(48, 48)
        Me.btn_nowe.TabIndex = 8
        Me.btn_nowe.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_nowe.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ToolTip1.SetToolTip(Me.btn_nowe, "Nowe wyszukiwanie")
        Me.btn_nowe.UseVisualStyleBackColor = True
        '
        'numertelefonu
        '
        Me.numertelefonu.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.numertelefonu.Location = New System.Drawing.Point(134, 8)
        Me.numertelefonu.MaxLength = 15
        Me.numertelefonu.Name = "numertelefonu"
        Me.numertelefonu.Size = New System.Drawing.Size(126, 23)
        Me.numertelefonu.TabIndex = 0
        Me.numertelefonu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ToolTip1.SetToolTip(Me.numertelefonu, "Wprowadź numer telefonu / ID połączenia")
        '
        'btn_koniec
        '
        Me.btn_koniec.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_koniec.Image = Global.HistoriaKontaktowCCC.My.Resources.Resources.big_exit
        Me.btn_koniec.Location = New System.Drawing.Point(730, 7)
        Me.btn_koniec.Name = "btn_koniec"
        Me.btn_koniec.Size = New System.Drawing.Size(48, 48)
        Me.btn_koniec.TabIndex = 10
        Me.btn_koniec.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_koniec.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ToolTip1.SetToolTip(Me.btn_koniec, "Zakończ działanie aplikacji")
        Me.btn_koniec.UseVisualStyleBackColor = True
        '
        'btn_export
        '
        Me.btn_export.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_export.Image = Global.HistoriaKontaktowCCC.My.Resources.Resources.export_csv
        Me.btn_export.Location = New System.Drawing.Point(681, 7)
        Me.btn_export.Name = "btn_export"
        Me.btn_export.Size = New System.Drawing.Size(48, 48)
        Me.btn_export.TabIndex = 9
        Me.btn_export.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_export.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ToolTip1.SetToolTip(Me.btn_export, "Eksport listy do CSV")
        Me.btn_export.UseVisualStyleBackColor = True
        '
        'btn_search
        '
        Me.btn_search.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_search.Enabled = False
        Me.btn_search.Image = Global.HistoriaKontaktowCCC.My.Resources.Resources.big_search
        Me.btn_search.Location = New System.Drawing.Point(583, 7)
        Me.btn_search.Name = "btn_search"
        Me.btn_search.Size = New System.Drawing.Size(48, 48)
        Me.btn_search.TabIndex = 7
        Me.btn_search.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btn_search.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.ToolTip1.SetToolTip(Me.btn_search, "Wyszukaj")
        Me.btn_search.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.PrefixList)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.DataGridView1)
        Me.Panel2.Location = New System.Drawing.Point(0, 63)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(784, 346)
        Me.Panel2.TabIndex = 4
        Me.Panel2.Visible = False
        '
        'PrefixList
        '
        Me.PrefixList.FormattingEnabled = True
        Me.PrefixList.Location = New System.Drawing.Point(704, 326)
        Me.PrefixList.Name = "PrefixList"
        Me.PrefixList.Size = New System.Drawing.Size(18, 17)
        Me.PrefixList.TabIndex = 4
        Me.PrefixList.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Label2.Location = New System.Drawing.Point(334, 153)
        Me.Label2.Name = "Label2"
        Me.Label2.Padding = New System.Windows.Forms.Padding(5)
        Me.Label2.Size = New System.Drawing.Size(118, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Trwa wyszukiwanie..."
        '
        'CLIDDataGridViewTextBoxColumn1
        '
        Me.CLIDDataGridViewTextBoxColumn1.DataPropertyName = "CL_ID"
        Me.CLIDDataGridViewTextBoxColumn1.HeaderText = "CL_ID"
        Me.CLIDDataGridViewTextBoxColumn1.Name = "CLIDDataGridViewTextBoxColumn1"
        Me.CLIDDataGridViewTextBoxColumn1.ReadOnly = True
        Me.CLIDDataGridViewTextBoxColumn1.Width = 117
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'IDPołączeniaDataGridViewTextBoxColumn
        '
        Me.IDPołączeniaDataGridViewTextBoxColumn.DataPropertyName = "ID Połączenia"
        Me.IDPołączeniaDataGridViewTextBoxColumn.HeaderText = "ID Połączenia"
        Me.IDPołączeniaDataGridViewTextBoxColumn.Name = "IDPołączeniaDataGridViewTextBoxColumn"
        Me.IDPołączeniaDataGridViewTextBoxColumn.ReadOnly = True
        Me.IDPołączeniaDataGridViewTextBoxColumn.Width = 102
        '
        'NumerTelefonuDataGridViewTextBoxColumn
        '
        Me.NumerTelefonuDataGridViewTextBoxColumn.DataPropertyName = "Numer telefonu"
        Me.NumerTelefonuDataGridViewTextBoxColumn.HeaderText = "Numer telefonu"
        Me.NumerTelefonuDataGridViewTextBoxColumn.Name = "NumerTelefonuDataGridViewTextBoxColumn"
        Me.NumerTelefonuDataGridViewTextBoxColumn.ReadOnly = True
        Me.NumerTelefonuDataGridViewTextBoxColumn.Width = 103
        '
        'RodzajPołączeniaDataGridViewTextBoxColumn
        '
        Me.RodzajPołączeniaDataGridViewTextBoxColumn.DataPropertyName = "Rodzaj połączenia"
        Me.RodzajPołączeniaDataGridViewTextBoxColumn.HeaderText = "Rodzaj połączenia"
        Me.RodzajPołączeniaDataGridViewTextBoxColumn.Name = "RodzajPołączeniaDataGridViewTextBoxColumn"
        Me.RodzajPołączeniaDataGridViewTextBoxColumn.ReadOnly = True
        Me.RodzajPołączeniaDataGridViewTextBoxColumn.Width = 102
        '
        'DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn
        '
        Me.DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn.DataPropertyName = "Data rozpoczęcia połączenia"
        Me.DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn.HeaderText = "Data rozpoczęcia połączenia"
        Me.DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn.Name = "DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn"
        Me.DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn.ReadOnly = True
        Me.DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn.Width = 102
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.opis_ilosc_pozycji, Me.ilosc_pozycji_znalezionych, Me.lbl_error_data_prefix, Me.lbl_error_data})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 412)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(784, 22)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'opis_ilosc_pozycji
        '
        Me.opis_ilosc_pozycji.Name = "opis_ilosc_pozycji"
        Me.opis_ilosc_pozycji.Size = New System.Drawing.Size(119, 17)
        Me.opis_ilosc_pozycji.Text = "Ilość pozycji na liście:"
        Me.opis_ilosc_pozycji.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ilosc_pozycji_znalezionych
        '
        Me.ilosc_pozycji_znalezionych.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ilosc_pozycji_znalezionych.Name = "ilosc_pozycji_znalezionych"
        Me.ilosc_pozycji_znalezionych.Size = New System.Drawing.Size(14, 17)
        Me.ilosc_pozycji_znalezionych.Text = "0"
        '
        'lbl_error_data_prefix
        '
        Me.lbl_error_data_prefix.Name = "lbl_error_data_prefix"
        Me.lbl_error_data_prefix.Size = New System.Drawing.Size(10, 17)
        Me.lbl_error_data_prefix.Text = "|"
        '
        'lbl_error_data
        '
        Me.lbl_error_data.ForeColor = System.Drawing.Color.Red
        Me.lbl_error_data.Name = "lbl_error_data"
        Me.lbl_error_data.Size = New System.Drawing.Size(337, 17)
        Me.lbl_error_data.Text = "Błąd: Data końcowa nie może być wcześniejsza niż początkowa"
        Me.lbl_error_data.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lbl_error_data.Visible = False
        '
        'ToolTip1
        '
        '
        'SearchBy
        '
        Me.SearchBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.SearchBy.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!)
        Me.SearchBy.FormattingEnabled = True
        Me.SearchBy.Items.AddRange(New Object() {"Numer telefonu", "ID połączenia"})
        Me.SearchBy.Location = New System.Drawing.Point(9, 8)
        Me.SearchBy.Name = "SearchBy"
        Me.SearchBy.Size = New System.Drawing.Size(119, 23)
        Me.SearchBy.TabIndex = 17
        Me.ToolTip1.SetToolTip(Me.SearchBy, "Wybierz rodzaj wyszkukiwania:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " - po numerze telefonu" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " - po ID połączenia")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 434)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(800, 125)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Historia kontaktów w ContactCenter | wersja 2.4 z 24.05.2016"
        CType(CCDBPPWielunDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CALLSBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MSSQL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MSSQL As BindingSource
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents CALLSBindingSource As BindingSource
    Friend WithEvents CALLSTableAdapter As CCDBPPWielunDataSetTableAdapters.CALLSTableAdapter
    Friend WithEvents btn_search As Button
    Friend WithEvents CLIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CL_ID As DataGridViewTextBoxColumn
    Friend WithEvents CL_DATA_FROM As DataGridViewTextBoxColumn
    Friend WithEvents CL_DATA_PICKUP As DataGridViewTextBoxColumn
    Friend WithEvents CL_DATA_TO As DataGridViewTextBoxColumn
    Friend WithEvents CzasPolaczenia As DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btn_koniec As Button
    Friend WithEvents btn_export As Button
    Friend WithEvents Panel2 As Panel
    Friend WithEvents numertelefonu As TextBox
    Friend WithEvents CLIDDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents CzyOdebraneDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Timer2 As Timer
    Friend WithEvents IDPołączeniaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NumerTelefonuDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RodzajPołączeniaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DataRozpoczęciaPołączeniaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents opis_ilosc_pozycji As ToolStripStatusLabel
    Friend WithEvents ilosc_pozycji_znalezionych As ToolStripStatusLabel
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents btn_nowe As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents combo_rodzaj As ComboBox
    Friend WithEvents dtp_data As DateTimePicker
    Friend WithEvents cb_data As CheckBox
    Friend WithEvents dtp_data_do As DateTimePicker
    Friend WithEvents lbl_error_data As ToolStripStatusLabel
    Friend WithEvents lbl_error_data_prefix As ToolStripStatusLabel
    Friend WithEvents Nagranie As DataGridViewButtonColumn
    Friend WithEvents Zapis As DataGridViewButtonColumn
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents PrefixList As ListBox
    Friend WithEvents WithRecording As CheckBox
    Friend WithEvents ListaAgentow As ComboBox
    Friend WithEvents ByAgent As CheckBox
    Friend WithEvents ToolTip2 As ToolTip
    Friend WithEvents SearchBy As ComboBox
End Class
