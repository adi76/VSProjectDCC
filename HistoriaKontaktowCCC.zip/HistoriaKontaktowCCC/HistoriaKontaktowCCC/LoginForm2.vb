﻿Imports System.DirectoryServices

Public Class LoginForm2

    ' TODO: Insert code to perform custom authentication using the provided username and password 
    ' (See http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' The custom principal can then be attached to the current thread's principal as follows: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' where CustomPrincipal is the IPrincipal implementation used to perform authentication. 
    ' Subsequently, My.User will return identity information encapsulated in the CustomPrincipal object
    ' such as the username, display name, etc.

    Public Function ValidateActiveDirectoryLogin(ByVal Domain As String, ByVal Username As String, ByVal Password As String) As Boolean

        Try
            'Build LDAP Correct Search String
            Dim SearchString As String = Nothing

            For i = 0 To Domain.Split(".").Count - 1
                SearchString &= "DC=" & Domain.Split(".")(i) & ", "
            Next

            SearchString = SearchString.TrimEnd(", ")
            'Setup Connection to LDAP
            Dim DirEntry As New DirectoryEntry("LDAP:  //" & SearchString)

            DirEntry.Username = Username
            DirEntry.Password = Password
            DirEntry.AuthenticationType = AuthenticationTypes.Secure

            'Test the Uesrname and Password by try a Native Ojbect Binding
            Dim NOjb As [Object] = DirEntry.NativeObject

            'If Try statement get this far the username and password have passed the check
            Return True

        Catch ex As Exception
            'Username/Password/Domain are combination are wrong
            MsgBox(ex.Message)
            Return False
        End Try
    End Function

    Public Function Check_If_Member_Of_AD_Group(ByVal username As String,
        ByVal grouptoCheck As String,
        ByVal domain As String,
        ByVal ADlogin As String,
        ByVal ADpassword As String) _
        As Boolean

        'This is a function that receives a username to see if it's a
        'member of a specific group in AD.


        Try
            'First let's put the whole thing in a nice big try catch, and
            'catch any errors.

            Dim EntryString As String
            EntryString = "LDAP: //" & domain
            'Above, we setup the LDAP basic entry string.

            Dim myDE As DirectoryEntry
            'Above, I dimension my DirectoryEntry object


            grouptoCheck = grouptoCheck.ToLower()
            'The groups returned may have different combinations of
            'lowercase and uppercase, so let's go ahead
            'and make grouptoCheck lowercase.


            If (ADlogin <> "" AndAlso ADpassword <> "") Then
                'If they provided a password, then add it
                'as an argument to the function
                'I recently learned about AndAlso, and it's pretty
                'cool. Basically it does not worry about checking
                'the next condition if the first one is not true.
                myDE = New DirectoryEntry(EntryString, ADlogin, ADpassword)
                'Above, we create a new instance of the Directory Entry
                'Includes login and password
            Else
                'Else, use the account credentials of the machine 
                'making the request. You might not be able to get 
                'away with this if your production server does not have 
                'rights to query Active Directory.
                'Then again, there are workarounds for anything.
                myDE = New DirectoryEntry(EntryString)
                'Above, we create a new instance of the Directory Entry
                'Does not include login and password
            End If

            Dim myDirectorySearcher As New DirectorySearcher(myDE)
            'Above we create new instance of a DirectorySearcher
            'We also specify the Directory Entry as an argument.

            myDirectorySearcher.Filter = "sAMAccountName=" & username
            'Above we specify to filter our results where
            'sAMAccountName is equal to our username passed in.
            myDirectorySearcher.PropertiesToLoad.Add("MemberOf")
            'We only care about the MemberOf Properties, and we
            'specify that above.

            Dim myresult As SearchResult = myDirectorySearcher.FindOne()
            'SearchResult is a node in Active Directory that is returned
            'during a search through System.DirectoryServices.DirectorySearcher
            'Above, we dim a myresult object, and assign a node returned
            'from myDirectorySearcher.FindOne()
            'I've never heard of similar login Id's in Active Directory, 
            'so I don't think we need to call FindAll(), so Instead 
            'we call FindOne()


            Dim NumberOfGroups As Integer
            NumberOfGroups = myresult.Properties("memberOf").Count() - 1
            'Above we get the number of groups the user is a memberOf, 
            'and store it in a variable. It is zero indexed, so we
            'remove 1 so we can loop through it.

            Dim tempString As String
            'A temp string that we will use to get only what we
            'need from the MemberOf string property

            While (NumberOfGroups >= 0)
                tempString = myresult.Properties("MemberOf").Item(NumberOfGroups)
                tempString = tempString.Substring(0, tempString.IndexOf(",", 0))
                'Above we set tempString to the first index of "," starting
                'from the zeroth element of itself.
                tempString = tempString.Replace("CN=", "")
                'Above, we remove the "CN=" from the beginning of the string
                tempString = tempString.ToLower() 'Lets make all letters lowercase
                tempString = tempString.Trim()
                'Finnally, we trim any blank characters from the edges

                If (grouptoCheck = tempString) Then
                    Return True
                End If
                'If we have a match, the return is true
                'username is a member of grouptoCheck

                NumberOfGroups = NumberOfGroups - 1
            End While


            'If the code reaches here, there was no match.
            'Return false
            Return False


        Catch ex As Exception

            MsgBox("Błąd: " & ex.ToString)

        End Try


    End Function

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        If (ValidateActiveDirectoryLogin("net.pp", UsernameTextBox.Text, PasswordTextBox.Text)) Then

            '   If (Check_If_Member_Of_AD_Group(UsernameTextBox.Text, "ggALL_P216085SCOF057_ContactCenter_Recordings", "net.pp", "SVC_LOD_ContactCente", "T@jNeHaSł0Do$tEpU2*I5")) Or (Check_If_Member_Of_AD_Group(UsernameTextBox.Text, "ggALL_P216085SCOF057_ContactCenter_Backoffice", "net.pp", "SVC_LOD_ContactCente", "T@jNeHaSł0Do$tEpU2*I5")) Or (Check_If_Member_Of_AD_Group(UsernameTextBox.Text, "ggALL_P216085SCOF057_ContactCenter_IT", "net.pp", "SVC_LOD_ContactCente", "T@jNeHaSł0Do$tEpU2*I5")) Then
            Form1.Show()
            Me.Visible = False
            '  Else

            'End If

        Else
            MessageBox.Show("Błędne hasło, spróbuj ponownie", "Błąd logowania")
            PasswordTextBox.Text = ""
        End If

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginForm2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UsernameTextBox.Text = Environment.UserName
        PasswordTextBox.Focus()
    End Sub
End Class
