﻿Imports System.DirectoryServices

Public NotInheritable Class SplashScreen1

    'TODO: This form can easily be set as the splash screen for the application by going to the "Application" tab
    '  of the Project Designer ("Properties" under the "Project" menu).


    Private Sub SplashScreen1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Set up the dialog text at runtime according to the application's assembly information.  

        'TODO: Customize the application's assembly information in the "Application" pane of the project 
        '  properties dialog (under the "Project" menu).

        'Application title
        If My.Application.Info.Title <> "" Then
            ApplicationTitle.Text = My.Application.Info.Title
        Else
            'If the application title is missing, use the application name, without the extension
            ApplicationTitle.Text = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If

        'Format the version information using the text set into the Version control at design time as the
        '  formatting string.  This allows for effective localization if desired.
        '  Build and revision information could be included by using the following code and changing the 
        '  Version control's designtime text to "Version {0}.{1:00}.{2}.{3}" or something similar.  See
        '  String.Format() in Help for more information.
        '
        '    Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor, My.Application.Info.Version.Build, My.Application.Info.Version.Revision)

        ' Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor)

        'Copyright info
        'Copyright.Text = My.Application.Info.Copyright

    End Sub

    Public Function Check_If_Member_Of_AD_Group(ByVal username As String,
        ByVal grouptoCheck As String,
        ByVal domain As String,
        ByVal ADlogin As String,
        ByVal ADpassword As String) _
        As Boolean

        'This is a function that receives a username to see if it's a
        'member of a specific group in AD.


        Try
            'First let's put the whole thing in a nice big try catch, and
            'catch any errors.

            Dim EntryString As String
            EntryString = "LDAP://" & domain
            'Above, we setup the LDAP basic entry string.

            Dim myDE As DirectoryEntry
            'Above, I dimension my DirectoryEntry object


            grouptoCheck = grouptoCheck.ToLower()
            'The groups returned may have different combinations of
            'lowercase and uppercase, so let's go ahead
            'and make grouptoCheck lowercase.


            If (ADlogin <> "" AndAlso ADpassword <> "") Then
                'If they provided a password, then add it
                'as an argument to the function
                'I recently learned about AndAlso, and it's pretty
                'cool. Basically it does not worry about checking
                'the next condition if the first one is not true.
                myDE = New DirectoryEntry(EntryString, ADlogin, ADpassword)
                'Above, we create a new instance of the Directory Entry
                'Includes login and password
            Else
                'Else, use the account credentials of the machine 
                'making the request. You might not be able to get 
                'away with this if your production server does not have 
                'rights to query Active Directory.
                'Then again, there are workarounds for anything.
                myDE = New DirectoryEntry(EntryString)
                'Above, we create a new instance of the Directory Entry
                'Does not include login and password
            End If

            Dim myDirectorySearcher As New DirectorySearcher(myDE)
            'Above we create new instance of a DirectorySearcher
            'We also specify the Directory Entry as an argument.

            myDirectorySearcher.Filter = "sAMAccountName=" & username
            'Above we specify to filter our results where
            'sAMAccountName is equal to our username passed in.
            myDirectorySearcher.PropertiesToLoad.Add("MemberOf")
            'We only care about the MemberOf Properties, and we
            'specify that above.

            Dim myresult As SearchResult = myDirectorySearcher.FindOne()
            'SearchResult is a node in Active Directory that is returned
            'during a search through System.DirectoryServices.DirectorySearcher
            'Above, we dim a myresult object, and assign a node returned
            'from myDirectorySearcher.FindOne()
            'I've never heard of similar login Id's in Active Directory, 
            'so I don't think we need to call FindAll(), so Instead 
            'we call FindOne()


            Dim NumberOfGroups As Integer
            NumberOfGroups = myresult.Properties("memberOf").Count() - 1
            'Above we get the number of groups the user is a memberOf, 
            'and store it in a variable. It is zero indexed, so we
            'remove 1 so we can loop through it.

            Dim tempString As String
            'A temp string that we will use to get only what we
            'need from the MemberOf string property

            While (NumberOfGroups >= 0)
                tempString = myresult.Properties("MemberOf").Item(NumberOfGroups)
                tempString = tempString.Substring(0, tempString.IndexOf(",", 0))
                'Above we set tempString to the first index of "," starting
                'from the zeroth element of itself.
                tempString = tempString.Replace("CN=", "")
                'Above, we remove the "CN=" from the beginning of the string
                tempString = tempString.ToLower() 'Lets make all letters lowercase
                tempString = tempString.Trim()
                'Finnally, we trim any blank characters from the edges

                If (grouptoCheck = tempString) Then
                    Return True
                End If
                'If we have a match, the return is true
                'username is a member of grouptoCheck

                NumberOfGroups = NumberOfGroups - 1
            End While


            'If the code reaches here, there was no match.
            'Return false
            Return False


        Catch ex As Exception

            MsgBox("Błąd: " & ex.ToString)

        End Try


    End Function

    Private Sub SplashScreen1_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown


    End Sub

    Private Sub SplashScreen1_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated

    End Sub

    Private Sub MainLayoutPanel_Paint(sender As Object, e As PaintEventArgs)

    End Sub
End Class
