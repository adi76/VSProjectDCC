﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text
Imports System.IO
Imports System.DirectoryServices

Public Class Form1
    Public Shared DS As String
    Public Shared Cat As String
    Public Shared Usr As String
    Public Shared Pwd As String
    Public Shared Path As String
    Public Shared QuietExit As Boolean = False
    Public Shared PrefixyDlaWychodzacych As New DataTable()
    Private dataAdapter As New SqlDataAdapter()

    Public Function Check_If_Member_Of_AD_Group(ByVal username As String,
        ByVal grouptoCheck As String,
        ByVal domain As String,
        ByVal ADlogin As String,
        ByVal ADpassword As String) _
        As Boolean

        'This is a function that receives a username to see if it's a
        'member of a specific group in AD.


        Try
            'First let's put the whole thing in a nice big try catch, and
            'catch any errors.

            Dim EntryString As String
            EntryString = "LDAP://" & domain
            'Above, we setup the LDAP basic entry string.

            Dim myDE As DirectoryEntry
            'Above, I dimension my DirectoryEntry object


            grouptoCheck = grouptoCheck.ToLower()
            'The groups returned may have different combinations of
            'lowercase and uppercase, so let's go ahead
            'and make grouptoCheck lowercase.


            If (ADlogin <> "" AndAlso ADpassword <> "") Then
                'If they provided a password, then add it
                'as an argument to the function
                'I recently learned about AndAlso, and it's pretty
                'cool. Basically it does not worry about checking
                'the next condition if the first one is not true.
                myDE = New DirectoryEntry(EntryString, ADlogin, ADpassword)
                'Above, we create a new instance of the Directory Entry
                'Includes login and password
            Else
                'Else, use the account credentials of the machine 
                'making the request. You might not be able to get 
                'away with this if your production server does not have 
                'rights to query Active Directory.
                'Then again, there are workarounds for anything.
                myDE = New DirectoryEntry(EntryString)
                'Above, we create a new instance of the Directory Entry
                'Does not include login and password
            End If

            Dim myDirectorySearcher As New DirectorySearcher(myDE)
            'Above we create new instance of a DirectorySearcher
            'We also specify the Directory Entry as an argument.

            myDirectorySearcher.Filter = "sAMAccountName=" & username
            'Above we specify to filter our results where
            'sAMAccountName is equal to our username passed in.
            myDirectorySearcher.PropertiesToLoad.Add("MemberOf")
            'We only care about the MemberOf Properties, and we
            'specify that above.

            Dim myresult As SearchResult = myDirectorySearcher.FindOne()
            'SearchResult is a node in Active Directory that is returned
            'during a search through System.DirectoryServices.DirectorySearcher
            'Above, we dim a myresult object, and assign a node returned
            'from myDirectorySearcher.FindOne()
            'I've never heard of similar login Id's in Active Directory, 
            'so I don't think we need to call FindAll(), so Instead 
            'we call FindOne()


            Dim NumberOfGroups As Integer
            NumberOfGroups = myresult.Properties("memberOf").Count() - 1
            'Above we get the number of groups the user is a memberOf, 
            'and store it in a variable. It is zero indexed, so we
            'remove 1 so we can loop through it.

            Dim tempString As String
            'A temp string that we will use to get only what we
            'need from the MemberOf string property

            While (NumberOfGroups >= 0)
                tempString = myresult.Properties("MemberOf").Item(NumberOfGroups)
                tempString = tempString.Substring(0, tempString.IndexOf(",", 0))
                'Above we set tempString to the first index of "," starting
                'from the zeroth element of itself.
                tempString = tempString.Replace("CN=", "")
                'Above, we remove the "CN=" from the beginning of the string
                tempString = tempString.ToLower() 'Lets make all letters lowercase
                tempString = tempString.Trim()
                'Finnally, we trim any blank characters from the edges

                If (grouptoCheck = tempString) Then
                    Return True
                End If
                'If we have a match, the return is true
                'username is a member of grouptoCheck

                NumberOfGroups = NumberOfGroups - 1
            End While


            'If the code reaches here, there was no match.
            'Return false
            Return False


        Catch ex As Exception

            MsgBox("Błąd: " & ex.ToString)

        End Try


    End Function

    Private Sub GetAgentsList()
        Dim con As New SqlConnection
        Dim cmd As New SqlCommand
        Dim tb_agent As New DataTable
        Dim err As Integer
        Dim err1 As String


        Try
            con.ConnectionString = "Data Source=" & DS & ";Initial Catalog=" & Cat & ";User ID=" & Usr & ";Password=" & Pwd & ""
            con.Open()
            cmd.Connection = con

            cmd.CommandText = "SELECT IDCONTACTIS, CONCAT(Nazwisko,' ',Imie) as iin FROM [CCDBPPwww].[dbo].[ListaPracownicyInfo] ORDER BY Nazwisko asc, imie asc"

            ListaAgentow.SelectedItem = Nothing
            ListaAgentow.DisplayMember = "Text"
            ListaAgentow.ValueMember = "Value"
            tb_agent.Columns.Add("Text", GetType(String))
            tb_agent.Columns.Add("Value", GetType(Integer))
            Dim sqlRdr As SqlDataReader
            sqlRdr = cmd.ExecuteReader()

            tb_agent.Rows.Add("", 0)

            Do While sqlRdr.Read
                tb_agent.Rows.Add(sqlRdr("iin"), sqlRdr("IDCONTACTIS"))
            Loop

            ListaAgentow.DataSource = tb_agent

            sqlRdr.Close()
        Catch ex As Exception
            Err = 1
            err1 = ex.Message
        Finally
            con.Close()
        End Try

    End Sub

    Private Sub GetPrefixes()
        Try
            DS = "10.216.85.46"
            Cat = "CCDBPPwww"
            Usr = "ccusrPPWielun"
            Pwd = "zaq1@wsxcCCPPWielun"

            Dim connectionString As String = "Data Source=" & DS & ";Initial Catalog=" & Cat & ";User ID=" & Usr & ";Password=" & Pwd & ""
            Dim da1 As New SqlDataAdapter("SELECT DISTINCT([CA_PREFIX]) FROM [CCDBPPWielun].[dbo].[CAMPAIGN_ACTIONS] WHERE [CA_ACTIVE] = 1", connectionString)

            da1.Fill(PrefixyDlaWychodzacych)

            For Each tempRow In PrefixyDlaWychodzacych.Rows
                'ListBox1.Items.Add((tempRow("ControlNo") & " (" & tempRow("EmpNo") & ")" & " (" & tempRow("CheckOutDate") & ")" & " (" & tempRow("CheckOutTime") & ")" & " (" & tempRow("TaxiNo") & ")" & " (" & tempRow("PlateNo") & ")" & " (" & tempRow("Model") & ")" & " (" & tempRow("Make") & ")"))
                'ListBox1.Items.Add((tempRow("ControlNo") & " (" & tempRow("EmpNo") & ")"))
                PrefixList.Items.Add(tempRow("CA_PREFIX"))
            Next

        Catch ex As SqlException
            MessageBox.Show("Wystąpił problem z połączeniem do serwera SQL. Sprawdź swoje połączenie sieciowe lub zgłoś ten problem do przełożonego. ")
        End Try
    End Sub

    Private Sub GetData(ByVal selectCommand As String)

        Try

            DS = "10.216.85.46"
            Cat = "CCDBPPwww"
            Usr = "ccusrPPWielun"
            Pwd = "zaq1@wsxcCCPPWielun"

            'Me.Outbound_e_zwrotyTableAdapter1.Fill(Me.CCDBPPWielunDataSet._Outbound_e_zwroty)
            'DataGridView1.DataSource = OutboundezwrotyBindingSource2
            'BindingNavigator1.BindingSource = OutboundezwrotyBindingSource2

            Dim connectionString As String = "Data Source=" & DS & ";Initial Catalog=" & Cat & ";User ID=" & Usr & ";Password=" & Pwd & ""
            Dim da As New SqlDataAdapter(selectCommand, connectionString)
            Dim dt As DataTable

            ' da = SqlDataAdapter(selectCommand, connectionString)
            dt = New DataTable()
            da.Fill(dt)
            DataGridView1.DataSource = dt

            '            If (SearchBy.SelectedIndex = 0) Then
            DataGridView1.Columns("Numer telefonu").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            DataGridView1.Columns("Numer telefonu").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            '            Else
            '           DataGridView1.Columns("Połączenie: Z -> Do").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            '          DataGridView1.Columns("Połączenie: Z -> Do").DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            '         End If
            '
            ' Create a new data adapter based on the specified query.
            '            dataAdapter = New SqlDataAdapter(selectCommand, connectionString)

            ' Create a command builder to generate SQL update, insert, and
            ' delete commands based on selectCommand. These are used to
            ' update the database.
            '           Dim commandBuilder As New SqlCommandBuilder(dataAdapter)

            ' Populate a new data table and bind it to the BindingSource.
            '            Dim table As New DataTable()
            '           table.Locale = System.Globalization.CultureInfo.InvariantCulture
            '          dataAdapter.Fill(table)
            '         Me.MSSQL.DataSource = table

            ' Resize the DataGridView columns to fit the newly loaded content.
            'Me.DataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader)
        Catch ex As SqlException
            MessageBox.Show("Wystąpił problem z połączeniem do serwera SQL. Sprawdź swoje połączenie sieciowe lub zgłoś ten problem do przełożonego. ")
        End Try

    End Sub


    Private Sub PokazHistorie()
        Dim Query As String

        Query = "SELECT TOP 500 "

        Query += "CASE WHEN c.CL_FILENAME IS NULL THEN '' ELSE '   ' END AS 'Nagranie',"
        Query += "CASE WHEN c.CL_FILENAME IS NULL THEN '' ELSE '   ' END AS 'Zapis',"

        Query += " c.CL_ID AS 'ID Połączenia', "

        If (SearchBy.SelectedIndex = 1) Then
            Query += " CONCAT(c.CL_CALLERID2,' -> ',c.cl_callerid1) AS 'Numer telefonu' ,"
        Else
            If (combo_rodzaj.SelectedIndex = 0) Then
                Query += "c.CL_CALLERID2 AS 'Numer telefonu',"
            Else
                Query += "c.CL_CALLERID1 AS 'Numer telefonu',"
            End If
        End If

        Query += "Case WHEN c.CL_TYPE = 1 THEN 'Przychodzące' 
	WHEN c.CL_TYPE = 3 THEN 'Wychodzące'"

        If (combo_rodzaj.SelectedIndex = 1) Then
            Query += " WHEN c.CL_TYPE = 6 THEN CONCAT('Z akcji marketingowej: ',CHAR(13),ca.ca_name) "
        Else
            Query += " WHEN c.CL_TYPE = 6 THEN 'Z akcji marketingowej' "
        End If

        Query += " Else 'Inne' END AS 'Rodzaj połączenia',
        CONCAT(u.USR_NAME,' ',u.USR_SURNAME) as 'Agent',
	Convert(varchar(19), c.CL_DATE_FROM, 120) As 'Data rozpoczęcia połączenia', 
	CASE WHEN (Convert(varchar(19), c.CL_DATE_PICKUP, 120)) IS NULL THEN '' ELSE (Convert(varchar(19), c.CL_DATE_PICKUP, 120)) END As 'Data wpadnięcia na IVR', 
	CASE WHEN (Convert(varchar(19), c.CL_DATE_TO, 120)) IS NULL THEN '' ELSE (Convert(varchar(19), c.CL_DATE_TO, 120)) END As 'Data zakończenia połączenia', 
	CASE WHEN (Convert(varchar(6), DateDiff(Second, c.CL_DATE_PICKUP, c.CL_DATE_TO) / 3600)+ ':'+ RIGHT('0' + CONVERT(varchar(2), (DATEDIFF(second, c.CL_DATE_PICKUP, c.CL_DATE_TO) % 3600) / 60), 2)+ ':'+ RIGHT('0' + CONVERT(varchar(2), DATEDIFF(second, c.CL_DATE_PICKUP, c.CL_DATE_TO) % 60), 2)) IS NULL THEN '' ELSE (Convert(varchar(6), DateDiff(Second, c.CL_DATE_PICKUP, c.CL_DATE_TO) / 3600)+ ':'+ RIGHT('0' + CONVERT(varchar(2), (DATEDIFF(second, c.CL_DATE_PICKUP, c.CL_DATE_TO) % 3600) / 60), 2)+ ':'+ RIGHT('0' + CONVERT(varchar(2), DATEDIFF(second, c.CL_DATE_PICKUP, c.CL_DATE_TO) % 60), 2)) END AS 'Czas połączenia',
	Case WHEN am.AM_DISCONNECT_SIDE = 1 THEN 'Klient' 
	WHEN am.AM_DISCONNECT_SIDE = 2 THEN 'Agent'
	WHEN am.AM_DISCONNECT_SIDE = 3 THEN 'Serwer' 
	WHEN am.AM_DISCONNECT_SIDE = 4 THEN 'Zerwane połączenie' 
	WHEN am.AM_DISCONNECT_SIDE = 5 THEN 'Podczas transferu' 
	ELSE '?' END AS 'Strona rozłączająca',
	CASE WHEN c.CL_FILENAME IS NULL THEN '' ELSE c.CL_FILENAME END AS 'Ścieżka do pliku z nagraniem' 

	FROM [CCDBPPWielun].[dbo].[CALLS] c 
    Left Join [CCDBPPWielun].[dbo].[ABSTRACT_MEDIA] am on c.CL_AM_ID=am.AM_ID "

        If (combo_rodzaj.SelectedIndex = 1) Then
            Query += " Left Join [CCDBPPWielun].[dbo].[OUTBOUND_CALLS] oc on c.CL_AM_ID=oc.OC_CL_ID Left Join [CCDBPPWielun].[dbo].[CAMPAIGN_ACTIONS] ca on oc.OC_CA_ID=ca.CA_ID "
        End If

        Query += " Left Join [CCDBPPWielun].[dbo].[USERS] u on am.AM_USR_ID=u.USR_ID "

        If (SearchBy.SelectedIndex = 0) Then
            If (combo_rodzaj.SelectedIndex = 0) Then
                ' przychodzące
                Query += " WHERE ((CL_CALLERID2 = '" & numertelefonu.Text & "') OR (CL_CALLERID2 = '0" & numertelefonu.Text & "') OR (CL_CALLERID2 = '00" & numertelefonu.Text & "') OR (CL_CALLERID2 = '48" & numertelefonu.Text & "')  OR (CL_CALLERID2 = '+48" & numertelefonu.Text & "'))"
            Else
                ' wychodzące
                Query += " WHERE ((CL_CALLERID1 = '" & numertelefonu.Text & "') OR "
                '(CL_CALLERID1 = '" & numertelefonu.Text & "') OR (CL_CALLERID1 = '0" & numertelefonu.Text & "') OR (CL_CALLERID1 = '00" & numertelefonu.Text & "') OR (CL_CALLERID1 = '48" & numertelefonu.Text & "')  OR (CL_CALLERID1 = '+48" & numertelefonu.Text & "'))"

                'Dim s As String = ""

                For index As Integer = 0 To PrefixList.Items.Count - 1
                    Query += "(CL_CALLERID1 = '" & PrefixList.Items(index) & numertelefonu.Text & "')"
                    If (index < PrefixList.Items.Count - 1) Then
                        Query += " OR "
                    End If
                Next
                Query += ")"

                'MsgBox(s)

            End If
        Else
            Query += " WHERE (c.CL_ID = " & numertelefonu.Text & ") "
        End If

        If (cb_data.Checked) Then
            Query += " And (CL_Date_FROM BETWEEN '" & dtp_data.Value.Date & " 00:00:00.000' AND '" & dtp_data_do.Value.Date & " 23:59:59.999')"
        End If

        If (WithRecording.Checked) Then
            Query += " And (c.CL_FILENAME IS NOT NULL)"
        End If

        If (ListaAgentow.SelectedIndex > 0) Then
            Query += " And (u.USR_ID = " & ListaAgentow.SelectedValue.ToString & ")"
        End If

        Query += " ORDER BY CL_ID DESC"
        'MsgBox(Query)
        'TextBox1.Text = Query

        GetData(Query)

        '= .nazwauzytkownika='" & nazwauzytkownika.Text & "' and R.data = '" & dtp_DataRejestracji.Value & "' 

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GetPrefixes()
        GetAgentsList()
        SearchBy.SelectedIndex = 0

        ToolTip2.SetToolTip(ListaAgentow, "Nazwisko Imię")

        ToolTip1.SetToolTip(btn_search, "Szukaj")
        ToolTip1.SetToolTip(btn_nowe, "Nowe szukanie")
        ToolTip1.SetToolTip(btn_export, "Zapisz wyniki do pliku CSV")
        ToolTip1.SetToolTip(btn_koniec, "Zakończ działanie aplikacji")

        ' Dostęp tylko dla członków grup: IT, BackOffice i Recordings

        If (Check_If_Member_Of_AD_Group(Environment.UserName, "ggALL_P216085SCOF057_ContactCenter_Recordings", "net.pp", "SVC_LOD_ContactCente", "T@jNeHaSł0Do$tEpU2*I5")) Or
           (Check_If_Member_Of_AD_Group(Environment.UserName, "ggALL_P216085SCOF057_ContactCenter_Backoffice", "net.pp", "SVC_LOD_ContactCente", "T@jNeHaSł0Do$tEpU2*I5")) Or
           (Check_If_Member_Of_AD_Group(Environment.UserName, "ggALL_P216085SCOF057_ContactCenter_IT", "net.pp", "SVC_LOD_ContactCente", "T@jNeHaSł0Do$tEpU2*I5")) Then

        Else
            QuietExit = True
            Me.Hide()

            MsgBox("Nie masz uprawnień do uruchamiania tej aplikacji")
            Application.Exit()

        End If


        'TODO: This line of code loads data into the 'CCDBPPWielunDataSet.CALLS' table. You can move, or remove it, as needed.
        ' Me.CALLSTableAdapter.Fill(Me.CCDBPPWielunDataSet.CALLS)
        Label2.Top = (Me.Height - 160) / 2
        Label2.Left = (Me.Width - 140) / 2

        btn_export.Enabled = False
        Me.Height = 125
        Panel2.Visible = False
        'DataGridView1.Visible = False

        ilosc_pozycji_znalezionych.Text = "0"

        Dim tb_rodzaj As New DataTable

        combo_rodzaj.SelectedItem = Nothing
        combo_rodzaj.DisplayMember = "Text"
        combo_rodzaj.ValueMember = "Value"

        tb_rodzaj.Columns.Add("Text", GetType(String))
        tb_rodzaj.Columns.Add("Value", GetType(Integer))

        tb_rodzaj.Rows.Add("Przychodzące", 0)
        tb_rodzaj.Rows.Add("Wychodzące", 1)
        'tb_rodzaj.Rows.Add("Wszystkie", 5)

        combo_rodzaj.DataSource = tb_rodzaj
        combo_rodzaj.SelectedIndex = 0

        dtp_data.Value = Now()
        dtp_data_do.Value = Now()

        dtp_data.Enabled = False
        dtp_data_do.Enabled = False

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_search.Click

        ' DataGridView1.DataSource = vbNull
        PokazHistorie()

        If (DataGridView1.RowCount > 0) Then

            Me.Height = 500
            Panel2.Visible = True
            Label2.Visible = True

            'DataGridView1.Visible = True

            ilosc_pozycji_znalezionych.Text = DataGridView1.RowCount
            btn_export.Enabled = True

            ilosc_pozycji_znalezionych.ForeColor = Color.Black
            opis_ilosc_pozycji.ForeColor = Color.Black

            ' Loading_gif.Visible = False
            '  Application.DoEvents()

            DataGridView1.Columns(0).Width = 30
            DataGridView1.Columns(1).Width = 30

        Else
            ' DataGridView1.Visible = False
            Panel2.Visible = False
            Me.Height = 125
            btn_export.Enabled = False
            ilosc_pozycji_znalezionych.Text = "0"
            'MsgBox("Brak informacji o podanym numerze w bazie CC", MsgBoxStyle.OkOnly, "Informacja")

            ilosc_pozycji_znalezionych.ForeColor = Color.Red
            opis_ilosc_pozycji.ForeColor = Color.Red

        End If

        Label2.Visible = False


        If (DataGridView1.RowCount > 300) Then
            MsgBox("Ilość wyników wyszukiwania osiągnęła ilość 500." & vbNewLine & vbNewLine & "Jeżeli na liście nie ma poszukiwanego połączenia, spróbuj zawęzić listę poprzez ograniczenie wyników wg: " & vbNewLine & vbNewLine & " - Data między " & vbNewLine & " - Z nagraniami " & vbNewLine & " - Nagranie")
        End If
    End Sub

    Private Sub numertelefonu_KeyPress(sender As Object, e As KeyPressEventArgs) Handles numertelefonu.KeyPress
        If Not Char.IsDigit(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        btn_search.Enabled = Not (numertelefonu.Text.Length < 6)
        btn_export.Enabled = (DataGridView1.Visible) And (DataGridView1.RowCount > 0)
        btn_nowe.Enabled = btn_export.Enabled

        If (dtp_data.Value.Date > dtp_data_do.Value.Date) Then
            lbl_error_data.Visible = True
            lbl_error_data_prefix.Visible = True
            btn_search.Enabled = False
            btn_export.Enabled = False
            btn_nowe.Enabled = False

        Else
            lbl_error_data.Visible = False
            lbl_error_data_prefix.Visible = False
            btn_search.Enabled = Not (numertelefonu.Text.Length < 6)
            btn_export.Enabled = (DataGridView1.Visible) And (DataGridView1.RowCount > 0)
            btn_nowe.Enabled = btn_export.Enabled
        End If

    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If (QuietExit = False) Then
            Dim result As Integer = MessageBox.Show("Czy napewno chcesz wyjść z programu ?", "Zakończ program", MessageBoxButtons.YesNo)
            If result = DialogResult.No Then
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub btn_koniec_Click(sender As Object, e As EventArgs) Handles btn_koniec.Click
        Me.Close()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        If e.ColumnIndex = 0 AndAlso e.RowIndex >= 0 Then
            Odtworz()
        End If

        If e.ColumnIndex = 1 AndAlso e.RowIndex >= 0 Then
            Zapisz()
        End If

    End Sub

    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        numertelefonu.Focus()
    End Sub

    Private Sub btn_export_Click(sender As Object, e As EventArgs) Handles btn_export.Click
        Dim fName As String = ""

        SaveFileDialog1.InitialDirectory = "."
        SaveFileDialog1.Filter = "CSV files (*.csv)|*.CSV"
        SaveFileDialog1.FilterIndex = 2
        SaveFileDialog1.RestoreDirectory = True

        If (SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            fName = SaveFileDialog1.FileName

            If (My.Computer.FileSystem.FileExists(fName)) Then
                Try
                    My.Computer.FileSystem.DeleteFile(fName)
                Catch ex As Exception
                    MessageBox.Show("Sprawdź czy plik do którego próbujesz zapisać dane nie jest otwarty. Zapis do pliku przerwany.", "Błąd podczas zapisu danych do pliku")
                    Exit Sub
                End Try

            End If
        Else Exit Sub
        End If

        Dim I As Integer = 0
        Dim j As Integer = 0
        Dim cellvalue$
        Dim rowLine As String = ""

        Try
            Dim objWriter As New System.IO.StreamWriter(fName, True, Encoding.UTF8)

            rowLine = "ID połączenia;Numer telefonu;Rodzaj połączenia;Agent;Data rozpoczęcia połączenia;Data wpadnięcia na IVR;Data zakończenia połączenia;Czas połączenia;Strona rozłączająca;Plik z nagraniem"


            objWriter.WriteLine(rowLine)
            rowLine = ""

            For j = 0 To (DataGridView1.Rows.Count - 1)
                For I = 2 To (DataGridView1.Columns.Count - 1)
                    If Not TypeOf DataGridView1.CurrentRow.Cells.Item(I).Value Is DBNull Then
                        cellvalue = DataGridView1.Item(I, j).Value
                    Else
                        cellvalue = ""
                    End If
                    rowLine = rowLine + cellvalue + ";"
                Next

                objWriter.WriteLine(rowLine)
                rowLine = ""
            Next
            objWriter.Close()
            MessageBox.Show("Pomyślnie zapisano dane do pliku", "Potwierdzenie zapisu")
        Catch ex As Exception
            MessageBox.Show("Wystąpił błąd podczas zapisywania danych do pliku." + ex.ToString())
        Finally
            FileClose(1)
        End Try

    End Sub

    Private Sub numertelefonu_KeyDown(sender As Object, e As KeyEventArgs) Handles numertelefonu.KeyDown
        If e.KeyCode = Keys.Enter Then
            '            System.Windows.Forms.SendKeys.Send("{TAB}")

            btn_search.PerformClick()
        End If

    End Sub

    Private Sub btn_nowe_Click(sender As Object, e As EventArgs) Handles btn_nowe.Click
        numertelefonu.Text = ""

        'DataGridView1.Visible = False
        'DataGridView1.DataSource = vbNull

        dtp_data.Value = Now()
        dtp_data_do.Value = Now()

        Panel2.Visible = False

        Me.Height = 105
        btn_export.Enabled = False
        ilosc_pozycji_znalezionych.Text = "0"
        numertelefonu.Focus()

        ListaAgentow.Text = ""
        ListaAgentow.Enabled = False
        ByAgent.Checked = False

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Resize(sender As Object, e As EventArgs) Handles MyBase.Resize
        Label2.Top = (Me.Height - 160) / 2
        Label2.Left = (Me.Width - 140) / 2

        ' Me.DataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader)
    End Sub

    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub cb_data_CheckedChanged(sender As Object, e As EventArgs) Handles cb_data.CheckedChanged
        dtp_data.Enabled = cb_data.Checked
        dtp_data_do.Enabled = cb_data.Checked
    End Sub

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs)
        Dim x As Integer

        Try
            x = DataGridView1.CurrentCell.RowIndex
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
            x = -1
        Finally
            If (DataGridView1.Rows(x).Cells(7).Value.ToString = "") Then
                e.Cancel = True
            End If
        End Try

    End Sub

    Private Sub DataGridView1_CellMouseDown(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseDown
        If e.ColumnIndex >= 0 And e.RowIndex >= 0 Then
            Me.DataGridView1.CurrentCell = Me.DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex)
        End If
    End Sub

    Private Sub Odtworz()
        Dim x As Integer

        Try
            x = DataGridView1.CurrentCell.RowIndex
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
            x = -1
        Finally
            If (x >= 0) Then
                If (DataGridView1.Rows(x).Cells(11).Value.ToString <> "") Then

                    Path = "\\10.216.85.38\nagrania\" & DataGridView1.Rows(x).Cells(11).Value.ToString

                    If My.Computer.FileSystem.FileExists(Path) Then

                        Dim result As Integer = MessageBox.Show("Czy napewno chcesz odtworzyć nagranie o ID = " & DataGridView1.Rows(x).Cells(2).Value.ToString & "?", "Pytanie", MessageBoxButtons.YesNo)

                        If result = DialogResult.Yes Then
                            Dim I As Integer
                            For I = 0 To (DataGridView1.Columns.Count - 1)
                                DataGridView1.Item(I, x).Style.BackColor = Color.GreenYellow
                            Next

                            Dim objshell = CreateObject("wscript.shell")
                            objshell.run(Path)

                        End If

                    Else

                        MsgBox("Brak wybranego nagrania na serwerze - nagranie przeniesione do archiwum." & vbNewLine & vbNewLine & "Skontaktuj się z administratorem w celu uzyskania nagrania o ID = " & DataGridView1.Rows(x).Cells(2).Value.ToString)

                        For I = 0 To (DataGridView1.Columns.Count - 1)
                            DataGridView1.Item(I, x).Style.BackColor = Color.OrangeRed
                        Next

                    End If
                Else
                    MsgBox("Dla wybranego połączenia nie ma nagrania.")
                End If
            End If
        End Try

    End Sub

    Private Sub Zapisz()
        Dim sFilename, dFilename As String
        Dim Source As String

        Dim x As Integer

        Try
            x = DataGridView1.CurrentCell.RowIndex
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
            x = -1
        Finally

            If (x >= 0) Then
                If (DataGridView1.Rows(x).Cells(11).Value.ToString <> "") Then

                    Source = DataGridView1.Rows(x).Cells(11).Value.ToString
                    sFilename = Mid(Source, InStrRev(Source, "\") + 1, Len(Source))
                    Path = "\\10.216.85.38\nagrania\" & DataGridView1.Rows(x).Cells(11).Value.ToString

                    Dim ok As Boolean = False

                    If My.Computer.FileSystem.FileExists(Path) Then

                        Try
                            Dim fDialog As New FolderBrowserDialog

                            If fDialog.ShowDialog() = DialogResult.Cancel Then
                                MsgBox("Anulowano zapis nagrania do pliku")
                            Else
                                dFilename = fDialog.SelectedPath & "\" & sFilename

                                If My.Computer.FileSystem.FileExists(dFilename) Then
                                    Dim result As Integer = MessageBox.Show("W podanej lokalizacji istnieje już wybrane nagranie. Czy nadpisać plik ?", "Pytanie", MessageBoxButtons.YesNo)

                                    If result = DialogResult.Yes Then
                                        My.Computer.FileSystem.CopyFile(Path, dFilename, True)
                                        ok = True
                                    Else
                                        ok = False
                                    End If

                                Else
                                    My.Computer.FileSystem.CopyFile(Path, dFilename, True)
                                    ok = True
                                End If

                                If (ok = True) Then
                                    For I = 0 To (DataGridView1.Columns.Count - 1)
                                        DataGridView1.Item(I, x).Style.BackColor = Color.ForestGreen
                                    Next
                                End If

                            End If

                        Catch ex As System.Exception
                            System.Windows.Forms.MessageBox.Show(ex.Message)
                        Finally
                            If (ok = True) Then
                                MsgBox("Nagranie zostało poprawnie zapisane")
                            End If
                        End Try

                    Else

                        MsgBox("Brak wybranego nagrania na serwerze - nagranie przeniesione do archiwum." & vbNewLine & vbNewLine & "Skontaktuj się z administratorem w celu uzyskania nagrania o ID = " & DataGridView1.Rows(x).Cells(2).Value.ToString)

                        For I = 0 To (DataGridView1.Columns.Count - 1)
                            DataGridView1.Item(I, x).Style.BackColor = Color.IndianRed
                        Next

                    End If
                Else
                    MsgBox("Dla wybranego połączenia nie ma nagrania.")
                End If
            End If
        End Try
    End Sub

    Private Sub DataGridView1_DoubleClick(sender As Object, e As EventArgs) Handles DataGridView1.DoubleClick
        Dim x, y As Integer

        Try
            x = DataGridView1.CurrentCell.RowIndex
            y = DataGridView1.CurrentCell.ColumnIndex
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
            x = -1
            y = -1
        Finally

            If (x >= 0) And (y = 0) Then

                Odtworz()

            End If

        End Try

    End Sub

    Public Function IsInGroup(ByVal GroupName As String) As Boolean
        Dim MyIdentity As System.Security.Principal.WindowsIdentity = System.Security.Principal.WindowsIdentity.GetCurrent()
        Dim MyPrincipal As System.Security.Principal.WindowsPrincipal = New System.Security.Principal.WindowsPrincipal(MyIdentity)
        Return MyPrincipal.IsInRole(GroupName)
    End Function

    Private Sub DataGridView1_CellPainting(sender As Object, e As DataGridViewCellPaintingEventArgs) Handles DataGridView1.CellPainting
        If e.ColumnIndex = 0 AndAlso e.RowIndex >= 0 Then

            If (DataGridView1.Rows(e.RowIndex).Cells(11).Value.ToString <> "") Then
                e.Paint(e.CellBounds, DataGridViewPaintParts.All)

                Dim bmpFind As Bitmap = My.Resources.play2
                Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
                e.Graphics.DrawIcon(ico, e.CellBounds.Left + 7, e.CellBounds.Top + 4)
                e.Handled = True
            Else
                e.Paint(e.CellBounds, DataGridViewPaintParts.All)

                Dim bmpFind As Bitmap = My.Resources.none
                Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
                e.Graphics.DrawIcon(ico, e.CellBounds.Left + 7, e.CellBounds.Top + 4)
                e.Handled = True
            End If

        End If

        If e.ColumnIndex = 1 AndAlso e.RowIndex >= 0 Then

            If (DataGridView1.Rows(e.RowIndex).Cells(11).Value.ToString <> "") Then
                e.Paint(e.CellBounds, DataGridViewPaintParts.All)

                Dim bmpFind As Bitmap = My.Resources.save3
                Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
                e.Graphics.DrawIcon(ico, e.CellBounds.Left + 7, e.CellBounds.Top + 4)
                e.Handled = True
            Else
                e.Paint(e.CellBounds, DataGridViewPaintParts.All)

                Dim bmpFind As Bitmap = My.Resources.none
                Dim ico As Icon = Icon.FromHandle(bmpFind.GetHicon)
                e.Graphics.DrawIcon(ico, e.CellBounds.Left + 7, e.CellBounds.Top + 4)
                e.Handled = True
            End If

        End If



    End Sub

    Private Sub ToolTip1_Popup(sender As Object, e As PopupEventArgs) Handles ToolTip1.Popup

    End Sub

    Private Sub numertelefonu_TextChanged(sender As Object, e As EventArgs) Handles numertelefonu.TextChanged

    End Sub

    Private Sub numertelefonu_Leave(sender As Object, e As EventArgs) Handles numertelefonu.Leave
        Dim n As Integer
        If (numertelefonu.Text <> "") Then
            If Not Int32.TryParse(numertelefonu.Text, n) Then
                MsgBox("Wprowadzono błędny numer telefonu")
                numertelefonu.Text = ""
                numertelefonu.Focus()
            End If
        End If
    End Sub

    Private Sub combo_rodzaj_SelectedIndexChanged(sender As Object, e As EventArgs) Handles combo_rodzaj.SelectedIndexChanged
        If (btn_search.Enabled = True) Then
            btn_search.PerformClick()
        End If
    End Sub

    Private Sub ListaAgentow_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ListaAgentow.KeyPress
        If Char.IsControl(e.KeyChar) Then Return

        With Me.ListaAgentow

            Dim ToFind As String = .Text.Substring(0, .SelectionStart) & e.KeyChar
            Dim Index As Integer = .FindStringExact(ToFind)

            If Index = -1 Then Index = .FindString(ToFind)
            If Index = -1 Then Return

            .SelectedIndex = Index
            .SelectionStart = ToFind.Length
            .SelectionLength = .Text.Length - .SelectionStart

            e.Handled = True

        End With
    End Sub

    Private Sub ListaAgentow_Leave(sender As Object, e As EventArgs) Handles ListaAgentow.Leave
        If (btn_search.Enabled = True) Then
            btn_search.PerformClick()
        End If
    End Sub

    Private Sub ListaAgentow_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ListaAgentow.Validating
        If (Not ListaAgentow.SelectedIndex > 0) And (ListaAgentow.Text <> "") Then
            MsgBox("Wprowadzonego agenta nie ma na liście")
            ListaAgentow.Text = ""
            ListaAgentow.Focus()
        End If
    End Sub

    Private Sub ByAgent_CheckedChanged(sender As Object, e As EventArgs) Handles ByAgent.CheckedChanged
        ListaAgentow.Enabled = ByAgent.Checked
        If (ByAgent.Checked = True) Then
            ListaAgentow.Focus()
        Else
            ListaAgentow.Text = ""
            btn_search.PerformClick()
        End If
    End Sub

    Private Sub WithRecording_CheckedChanged(sender As Object, e As EventArgs) Handles WithRecording.CheckedChanged
        If (btn_search.Enabled = True) Then
            btn_search.PerformClick()
        End If
    End Sub

    Private Sub ListaAgentow_KeyDown(sender As Object, e As KeyEventArgs) Handles ListaAgentow.KeyDown
        If e.KeyCode = Keys.Enter Then
            System.Windows.Forms.SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub dtp_data_KeyDown(sender As Object, e As KeyEventArgs) Handles dtp_data.KeyDown
        If e.KeyCode = Keys.Enter Then
            System.Windows.Forms.SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub dtp_data_do_KeyDown(sender As Object, e As KeyEventArgs) Handles dtp_data_do.KeyDown
        If e.KeyCode = Keys.Enter Then
            System.Windows.Forms.SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub SearchBy_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SearchBy.SelectedIndexChanged
        If SearchBy.SelectedIndex = 0 Then
            Label3.Visible = True
            combo_rodzaj.Visible = True
            cb_data.Enabled = True
            dtp_data.Enabled = True
            dtp_data_do.Enabled = True
            WithRecording.Enabled = True
            ByAgent.Enabled = True
            ListaAgentow.Enabled = True
        Else
            Label3.Visible = False
            combo_rodzaj.Visible = False
            cb_data.Enabled = False
            dtp_data.Enabled = False
            dtp_data_do.Enabled = False
            WithRecording.Enabled = False
            ByAgent.Enabled = False
            ListaAgentow.Enabled = False
        End If
        numertelefonu.Text = ""
        numertelefonu.Focus()
    End Sub
End Class